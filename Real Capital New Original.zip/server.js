const express = require('express');
const fs = require('fs');
const path = require('path');
const nodemailer = require('nodemailer');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const app = express();
const PORT = process.env.PORT || 3000;

app.disable('x-powered-by');
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));
app.use(express.static(__dirname, { dotfiles: 'deny', index: false }));
app.use(helmet());
app.use(helmet.contentSecurityPolicy({
    useDefaults: true,
    directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", 'data:'],
        connectSrc: ["'self'"],
        frameAncestors: ["'none'"],
        baseUri: ["'self'"],
    }
}));

// Basic rate limiting for auth-related endpoints
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 30, standardHeaders: true, legacyHeaders: false });
const apiLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 120, standardHeaders: true, legacyHeaders: false });
app.use('/api/', apiLimiter);
app.use('/api/auth/', authLimiter);
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'portal.html'));
});

// Data folder in the project directory for persistence
const DATA_FOLDER = path.join(__dirname, 'capital-pool-data');
const LOGIN_DB_FILE = path.join(DATA_FOLDER, 'login-database.json');
const LEGACY_DB_FILE = path.join(__dirname, 'database.json');

// Ensure data folder exists and migrate existing legacy DB into login DB if needed
if (!fs.existsSync(DATA_FOLDER)) {
    try { fs.mkdirSync(DATA_FOLDER, { recursive: true }); } catch (e) { console.error('Failed to create data folder:', e); }
}

// If login DB missing but legacy DB exists, copy it to login DB to preserve records
if (!fs.existsSync(LOGIN_DB_FILE) && fs.existsSync(LEGACY_DB_FILE)) {
    try {
        const content = fs.readFileSync(LEGACY_DB_FILE, 'utf8') || '[]';
        fs.writeFileSync(LOGIN_DB_FILE, content, 'utf8');
        console.log('Migrated legacy database.json into login-database.json');
    } catch (err) {
        console.error('Migration error:', err);
    }
}

// Use the login database file for all authentication/profile persistence
const DB_FILE = LOGIN_DB_FILE;

// Clean up any legacy Google login history fields from existing records.
const existingDb = readDatabase();
if (existingDb.length) {
    sanitizeLegacyGoogleHistory(existingDb);
}

// --- MAIL CARRIER CONFIGURATION ---
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'sergiomattew6@gmail.com',
        pass: 'uocs clhx zryr aexa'
    }
});

// --- HELPER FUNCTION: PARSE RAW REQ COOKIE HEADERS ---
function getCookie(req, name) {
    const matches = req.headers.cookie && req.headers.cookie.match(new RegExp(
        "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
    ));
    return matches ? decodeURIComponent(matches[1]) : undefined;
}

function readDatabase() {
    try {
        if (!fs.existsSync(DB_FILE)) return [];
        const rawData = fs.readFileSync(DB_FILE, 'utf8');
        return JSON.parse(rawData || '[]');
    } catch (error) {
        console.error("Database read error:", error);
        return [];
    }
}

function writeDatabase(data) {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 4), 'utf8');
}

function sanitizeLegacyGoogleHistory(database) {
    let changed = false;
    (database || []).forEach(user => {
        if (user.googleLoginHistory) {
            delete user.googleLoginHistory;
            changed = true;
        }
        if (user.authProvider === 'google') {
            delete user.authProvider;
            changed = true;
        }
        if (Array.isArray(user.loginHistory)) {
            const filtered = user.loginHistory.filter(entry => entry.provider !== 'google');
            if (filtered.length !== user.loginHistory.length) {
                user.loginHistory = filtered;
                changed = true;
            }
        }
    });
    if (changed) {
        writeDatabase(database);
    }
}

// --- HELPERS ---
function generateNodeCode() {
    return Math.floor(100000000 + Math.random() * 900000000).toString();
}

// --- TICKET GENERATION ENDPOINT ---
app.post('/api/tickets/generate', (req, res) => {
    const sessionEmail = getCookie(req, 'cp_session_email');
    if (!sessionEmail) return res.status(401).json({ success: false, message: 'Unauthorized' });

    const database = readDatabase();
    const userIndex = database.findIndex(u => u.email.toLowerCase() === sessionEmail.toLowerCase());
    if (userIndex === -1) return res.status(404).json({ success: false, message: 'User not found' });

    const { shares = 1, cost = 5000 } = req.body || {};
    const ticketCost = Number(cost);
    const ticketShares = Number(shares) || 1;
    if (isNaN(ticketCost) || ticketCost <= 0) {
        return res.status(400).json({ success: false, message: 'Invalid ticket cost specified.' });
    }

    const ticketPayback = Math.floor(ticketCost / 2);
    const ticket = {
        cycle: '#CP-01',
        date: new Date().toLocaleString('en-NG', { timeZone: 'Africa/Lagos', year: 'numeric', month: 'long', day: 'numeric' }),
        shares: ticketShares,
        status: 'Pending Verification',
        winnerTier: 'bronze',
        prize: null,
        prizeMessage: 'Ticket waiting for cycle selection.',
        additionalInfoNotice: 'Ensure your profile details are complete so we can reach you if selected.',
        cost: `₦${ticketCost.toLocaleString()}`,
        payback: `₦${ticketPayback.toLocaleString()}`,
        rawCost: ticketCost,
        rawPayback: ticketPayback,
        nodeCode: generateNodeCode(),
        requireProfile: !database[userIndex].profileCompleted
    };

    if (!database[userIndex].ticketHistory) database[userIndex].ticketHistory = [];
    database[userIndex].ticketHistory.push(ticket);
    writeDatabase(database);

    res.json({ success: true, ticket });
});

// --- RUN SELECTION: GRAND + UP TO 5 SECONDARY WINNERS ---
app.post('/api/selection/run', (req, res) => {
    const selectionFile = path.join(DATA_FOLDER, 'selection.json');
    const historyFile = path.join(DATA_FOLDER, 'selection_history.json');
    const database = readDatabase();

    // collect all eligible tickets (only tickets with a nodeCode)
    const pool = [];
    database.forEach(user => {
        (user.ticketHistory || []).forEach(t => {
            if (t.nodeCode) {
                pool.push({ userEmail: user.email, nodeCode: t.nodeCode, ticket: t });
            }
        });
    });

    if (pool.length === 0) return res.status(400).json({ success: false, message: 'No tickets to select from' });

    // pick grand winner
    const grandIndex = Math.floor(Math.random() * pool.length);
    const grand = pool.splice(grandIndex, 1)[0];

    // pick up to 5 secondary winners
    const secondary = [];
    for (let i = 0; i < 5 && pool.length > 0; i++) {
        const idx = Math.floor(Math.random() * pool.length);
        secondary.push(pool.splice(idx, 1)[0]);
    }

    // determine cycle from grand ticket or fallback
    const cycleCode = (grand && grand.ticket && grand.ticket.cycle) || '#CP-01';

    // mark all tickets: winners vs losers
    database.forEach(user => {
        (user.ticketHistory || []).forEach(t => {
            // ensure raw values exist
            const raw = t.rawCost || parseInt((t.cost || '').replace(/[^0-9]/g, '')) || 0;
            const payback = Math.floor(raw / 2);

            // winner: grand
            if (t.nodeCode === (grand && grand.nodeCode)) {
                t.status = 'Grand Winner';
                t.winnerTier = 'gold';
                t.prize = '₦25,000,000';
                t.prizeMessage = 'Congratulations! You are the cycle grand prize winner. Await our call and reward.';
                t.additionalInfoNotice = 'Please complete your additional profile information so we can reach you.';
                t.requireProfile = !user.profileCompleted;
            } else if (secondary.find(s => s.nodeCode === t.nodeCode)) {
                t.status = 'Secondary Winner';
                t.winnerTier = 'silver';
                t.prize = '₦500,000';
                t.prizeMessage = 'You are part of the secondary winners. Please await your reward.';
                t.additionalInfoNotice = 'Please complete your additional profile information so we can reach you.';
                t.requireProfile = !user.profileCompleted;
            } else {
                // not selected -> mark lost and credit cashback to wallet
                t.status = 'Lost';
                t.winnerTier = 'none';
                t.prize = '₦0';
                t.prizeMessage = 'Ticket not selected. 50% cashback has been credited to your wallet.';
                t.additionalInfoNotice = '';
                t.payback = `₦${payback.toLocaleString()}`;
                t.rawPayback = payback;
                user.walletBalance = (user.walletBalance || 0) + payback;
            }
        });
    });

    // Build selection summary with richer data for ledger transparency
    const buildDetails = (email, nodeCode, prize) => {
        const u = database.find(x => x.email.toLowerCase() === (email || '').toLowerCase());
        return {
            email: email,
            nodeCode,
            prize,
            firstName: u ? u.firstName : null,
            phone: u ? u.phone : null,
            profileCompleted: u ? !!u.profileCompleted : false,
            profileDetails: u ? u.profileDetails : null
        };
    };

    const buildTicketDetails = (email, nodeCode, prize) => {
        const u = database.find(x => x.email.toLowerCase() === (email || '').toLowerCase());
        const ticket = u ? (u.ticketHistory || []).find(item => item.nodeCode === nodeCode) : null;
        return {
            email: email,
            nodeCode,
            prize,
            winnerTier: ticket ? ticket.winnerTier : null,
            firstName: u ? u.firstName : null,
            phone: u ? u.phone : null,
            profileCompleted: u ? !!u.profileCompleted : false,
            profileDetails: u ? u.profileDetails : null
        };
    };

    const selectionSummary = {
        cycle: cycleCode,
        date: new Date().toLocaleString('en-NG', { timeZone: 'Africa/Lagos' }),
        grand: buildTicketDetails(grand.userEmail, grand.nodeCode, '₦25,000,000'),
        secondary: secondary.map(s => buildTicketDetails(s.userEmail, s.nodeCode, '₦500,000'))
    };

    // persist DB and selection history
    writeDatabase(database);
    try {
        fs.writeFileSync(selectionFile, JSON.stringify(selectionSummary, null, 4), 'utf8');
        // append to history array
        let history = [];
        if (fs.existsSync(historyFile)) {
            try { history = JSON.parse(fs.readFileSync(historyFile, 'utf8') || '[]'); } catch (e) { history = []; }
        }
        history.unshift(selectionSummary);
        fs.writeFileSync(historyFile, JSON.stringify(history, null, 4), 'utf8');
    } catch (err) {
        console.error('Failed to write selection file or history:', err);
    }

    res.json({ success: true, selection: selectionSummary });
});
// --- AUTHENTICATION INTEGRITY STATUS CHECKER ---
app.get('/api/auth/status', (req, res) => {
    const sessionEmail = getCookie(req, 'cp_session_email');
    if (!sessionEmail) {
        return res.json({ loggedIn: false });
    }

    const database = readDatabase();
    const matchedUser = database.find(user => user.email.toLowerCase() === sessionEmail.toLowerCase());

    if (!matchedUser) {
        return res.json({ loggedIn: false });
    }

    res.json({
        loggedIn: true,
        firstName: matchedUser.firstName,
        email: matchedUser.email
    });
});

// --- REGISTER ACCOUNT ROUTE ---
app.post('/api/auth/signup', (req, res) => {
    const { firstName, phone, email, password } = req.body;
    let database = readDatabase();

    const userExists = database.some(user => user.email.toLowerCase() === email.toLowerCase());
    if (userExists) {
        return res.status(400).json({ success: false, message: "Account email has already been taken." });
    }

    const verificationCode = Math.floor(100000 + Math.random() * 900000).toString();
    const verificationCodeExpiresAt = Date.now() + 1000 * 60 * 30; // 30 minutes

    const hashed = bcrypt.hashSync(password, 10);
    const newScholar = {
        firstName,
        phone,
        email: email.toLowerCase(),
        password: hashed,
        isVerified: false,
        verificationCode,
        verificationCodeExpiresAt,
        loginHistory: [],
        ticketHistory: [],
        profileCompleted: false,
        profileDetails: null,
        walletBalance: 0
    };

    database.push(newScholar);
    writeDatabase(database);
    
    res.json({ 
        success: true, 
        message: "Account registered. A 6-digit verification code has been sent to your email.", 
        firstName,
        email: email.toLowerCase()
    });

    const mailOptions = {
        from: '"Capital Pool" <sergiomattew6@gmail.com>',
        to: email.toLowerCase(),
        subject: 'Your Capital Pool Verification Code',
        html: `<div style="font-family: sans-serif; padding: 20px; background-color: #111; color: #fff; border-radius: 8px;">
            <h2 style="color: #ffab00;">CAPITAL POOL</h2>
            <p>Hello ${firstName},</p>
            <p>Use the code below to verify your account and activate access:</p>
            <div style="margin: 18px 0; padding: 18px; background: #091e42; border-radius: 6px; font-size: 1.5rem; letter-spacing: 0.2rem; text-align: center;">
                <strong>${verificationCode}</strong>
            </div>
            <p style="font-size: 0.95rem; color: #a5adba;">This code expires in 30 minutes.</p>
        </div>`
    };

    transporter.sendMail(mailOptions, (err) => {
        if (err) console.log("Verification email sending failed:", err.message);
    });
});

// --- EMAIL VERIFICATION CODE ENDPOINT ---
app.post('/api/auth/verify-code', (req, res) => {
    const { email, code } = req.body;
    if (!email || !code) {
        return res.status(400).json({ success: false, message: 'Email and verification code are required.' });
    }

    let database = readDatabase();
    const userIndex = database.findIndex(user => user.email.toLowerCase() === email.toLowerCase());
    if (userIndex === -1) {
        return res.status(404).json({ success: false, message: 'No account found with that email.' });
    }

    const user = database[userIndex];
    if (user.isVerified) {
        return res.status(400).json({ success: false, message: 'Account already verified. Please login.' });
    }

    if (!user.verificationCode || user.verificationCode !== code) {
        return res.status(400).json({ success: false, message: 'Invalid verification code.' });
    }

    if (Date.now() > (user.verificationCodeExpiresAt || 0)) {
        return res.status(400).json({ success: false, message: 'Verification code has expired. Please request a new code.' });
    }

    user.isVerified = true;
    user.verificationCode = null;
    user.verificationCodeExpiresAt = null;
    writeDatabase(database);

    res.json({ success: true, message: 'Email verified successfully. You may now login.' });
});

// --- RESEND VERIFICATION CODE ---
app.post('/api/auth/resend-code', (req, res) => {
    const { email } = req.body;
    if (!email) {
        return res.status(400).json({ success: false, message: 'Email is required to resend verification code.' });
    }

    let database = readDatabase();
    const userIndex = database.findIndex(user => user.email.toLowerCase() === email.toLowerCase());
    if (userIndex === -1) {
        return res.status(404).json({ success: false, message: 'No account found with that email.' });
    }

    const user = database[userIndex];
    if (user.isVerified) {
        return res.status(400).json({ success: false, message: 'Account already verified. Please login.' });
    }

    const verificationCode = Math.floor(100000 + Math.random() * 900000).toString();
    user.verificationCode = verificationCode;
    user.verificationCodeExpiresAt = Date.now() + 1000 * 60 * 30;
    writeDatabase(database);

    const mailOptions = {
        from: '"Capital Pool" <sergiomattew6@gmail.com>',
        to: email.toLowerCase(),
        subject: 'Your renewed Capital Pool verification code',
        html: `<div style="font-family: sans-serif; padding: 20px; background-color: #111; color: #fff; border-radius: 8px;">
            <h2 style="color: #ffab00;">CAPITAL POOL</h2>
            <p>Your new verification code is:</p>
            <div style="margin: 18px 0; padding: 18px; background: #091e42; border-radius: 6px; font-size: 1.5rem; letter-spacing: 0.2rem; text-align: center;">
                <strong>${verificationCode}</strong>
            </div>
            <p style="font-size: 0.95rem; color: #a5adba;">This code expires in 30 minutes.</p>
        </div>`
    };

    transporter.sendMail(mailOptions, (err) => {
        if (err) console.log("Resend code email failed:", err.message);
    });

    res.json({ success: true, message: 'A new verification code has been sent to your email.' });
});

// --- FORGOT PASSWORD / RESET FLOW ---
app.post('/api/auth/request-password-reset', (req, res) => {
    const { email } = req.body;
    if (!email) {
        return res.status(400).json({ success: false, message: 'Please provide the email associated with your account.' });
    }

    let database = readDatabase();
    const userIndex = database.findIndex(user => user.email.toLowerCase() === email.toLowerCase());
    if (userIndex === -1) {
        return res.status(404).json({ success: false, message: 'No registered account found with that email address. Please sign up first.' });
    }

    const resetCode = Math.floor(100000 + Math.random() * 900000).toString();
    database[userIndex].passwordResetCode = resetCode;
    database[userIndex].passwordResetExpiresAt = Date.now() + 1000 * 60 * 30;
    writeDatabase(database);

    const mailOptions = {
        from: '"Capital Pool" <sergiomattew6@gmail.com>',
        to: email.toLowerCase(),
        subject: 'Capital Pool Password Reset Code',
        html: `<div style="font-family: sans-serif; padding: 20px; background-color: #111; color: #fff; border-radius: 8px;">
            <h2 style="color: #ffab00;">CAPITAL POOL</h2>
            <p>Hello,</p>
            <p>Use the code below to reset your password. This code expires in 30 minutes.</p>
            <div style="margin: 18px 0; padding: 18px; background: #091e42; border-radius: 6px; font-size: 1.5rem; letter-spacing: 0.2rem; text-align: center;">
                <strong>${resetCode}</strong>
            </div>
            <p style="font-size: 0.95rem; color: #a5adba;">If you did not request this change, ignore this email and contact support.</p>
        </div>`
    };

    transporter.sendMail(mailOptions, (err) => {
        if (err) console.log("Password reset email failed:", err.message);
    });

    res.json({ success: true, message: 'A password reset code has been sent to your email address.' });
});

app.post('/api/auth/reset-password', (req, res) => {
    const { email, code, newPassword } = req.body;
    if (!email || !code || !newPassword) {
        return res.status(400).json({ success: false, message: 'Email, reset code and new password are required.' });
    }

    let database = readDatabase();
    const userIndex = database.findIndex(user => user.email.toLowerCase() === email.toLowerCase());
    if (userIndex === -1) {
        return res.status(404).json({ success: false, message: 'No registered account found with that email address.' });
    }

    const user = database[userIndex];
    if (!user.passwordResetCode || user.passwordResetCode !== code) {
        return res.status(400).json({ success: false, message: 'Invalid reset code. Please request a new code if necessary.' });
    }

    if (Date.now() > (user.passwordResetExpiresAt || 0)) {
        return res.status(400).json({ success: false, message: 'Reset code has expired. Please request a new one.' });
    }

    user.password = bcrypt.hashSync(newPassword, 10);
    user.passwordResetCode = null;
    user.passwordResetExpiresAt = null;
    writeDatabase(database);

    res.json({ success: true, message: 'Your password has been updated successfully. You may now login with the new password.' });
});

// --- LOGIN ACCOUNT ROUTE ---
app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body;
    let database = readDatabase();

    const userIndex = database.findIndex(user => user.email.toLowerCase() === email.toLowerCase());
    if (userIndex === -1) {
        return res.status(404).json({ success: false, message: "No account found matching this email." });
    }

    const storedHash = database[userIndex].password || '';
    let passwordMatches = false;
    try {
        passwordMatches = bcrypt.compareSync(password, storedHash);
    } catch (e) {
        passwordMatches = false;
    }

    // Fallback for legacy plaintext passwords: if direct match, re-hash and migrate
    if (!passwordMatches) {
        if (storedHash === password) {
            // migrate to hashed password
            const newHash = bcrypt.hashSync(password, 10);
            database[userIndex].password = newHash;
            writeDatabase(database);
            passwordMatches = true;
        }
    }

    if (!passwordMatches) {
        return res.status(401).json({ success: false, message: "Incorrect password credentials." });
    }

    if (!database[userIndex].isVerified) {
        return res.status(403).json({ success: false, message: "Account not verified. Please enter the 6-digit code sent to your email." });
    }

    if (!database[userIndex].loginHistory) {
        database[userIndex].loginHistory = [];
    }

    const loginTimestamp = new Date().toLocaleString('en-NG', { timeZone: 'Africa/Lagos' });
    
    database[userIndex].loginHistory.push({
        timestamp: loginTimestamp,
        deviceInfo: req.headers['user-agent'] || 'Unknown Device Space'
    });

    writeDatabase(database);

    // FIXED: Changed SameSite from Strict to Lax for reliable local session cross-talk on mobile browsers
    res.setHeader('Set-Cookie', `cp_session_email=${encodeURIComponent(database[userIndex].email)}; Path=/; HttpOnly; Max-Age=7200; SameSite=Lax`);

    res.json({ 
        success: true, 
        message: "Access granted.", 
        firstName: database[userIndex].firstName,
        email: database[userIndex].email
    });
});

// --- SECURE TERMINAL SESSION LOGOUT ---
app.post('/api/auth/logout', (req, res) => {
    res.setHeader('Set-Cookie', 'cp_session_email=; Path=/; HttpOnly; Max-Age=0; SameSite=Lax');
    res.json({ success: true, message: "Terminal session token cleared safely." });
});

// --- ROUTE TO SAVE AND LOCK PROFILE DETAILS ---
app.post('/api/user/update-profile', (req, res) => {
    const sessionEmail = getCookie(req, 'cp_session_email');
    if (!sessionEmail) {
        return res.status(401).json({ success: false, message: "Unauthorized access token." });
    }

    const { fullName, phone, university, preference, bankName, accountNumber } = req.body;
    let database = readDatabase();

    if (!fullName || !phone || !university || !preference) {
        return res.status(400).json({ success: false, message: "All profile fields are required." });
    }

    if (preference === 'money' && (!bankName || !accountNumber)) {
        return res.status(400).json({ success: false, message: "Bank name and account number are required for money preference." });
    }

    const userIndex = database.findIndex(user => user.email.toLowerCase() === sessionEmail.toLowerCase());
    if (userIndex === -1) {
        return res.status(404).json({ success: false, message: "User account context not found." });
    }

    database[userIndex].profileCompleted = true;
    database[userIndex].profileDetails = {
        fullName,
        phone,
        university,
        preference,
        bankName: preference === 'money' ? bankName : null,
        accountNumber: preference === 'money' ? accountNumber : null
    };

    writeDatabase(database);
    res.json({ success: true, message: "Profile parameters securely locked to data node." });
});

// --- GET USER PROFILE DATA FOR DASHBOARD METRICS ---
app.get('/api/user/profile', (req, res) => {
    let userEmail = getCookie(req, 'cp_session_email') || req.query.email;
    
    if (!userEmail) {
        return res.status(400).json({ success: false, message: "Missing authorization verification token." });
    }

    const database = readDatabase();
    const activeUser = database.find(user => user.email.toLowerCase() === userEmail.toLowerCase());

    if (!activeUser) {
        return res.status(404).json({ success: false, message: "User profile context not found in database." });
    }

    res.json({
        success: true,
        firstName: activeUser.firstName,
        email: activeUser.email,
        ticketHistory: activeUser.ticketHistory || [],
        profileCompleted: activeUser.profileCompleted || false, 
        profileDetails: activeUser.profileDetails || null       
    });
});

// --- GET RECENT SELECTION SUMMARY (Grand + Secondary winners)
app.get('/api/selection/recent', (req, res) => {
    const selectionFile = path.join(DATA_FOLDER, 'selection.json');
    try {
        if (!fs.existsSync(selectionFile)) {
            return res.json({ success: true, selection: null, message: 'No selection yet' });
        }
        const raw = fs.readFileSync(selectionFile, 'utf8') || 'null';
        const data = JSON.parse(raw);
        return res.json({ success: true, selection: data });
    } catch (err) {
        console.error('Error reading selection file:', err);
        return res.status(500).json({ success: false, message: 'Failed to load selection summary.' });
    }
});

// AI-style support chatbot endpoint
app.post('/api/support/message', (req, res) => {
    const rawMessage = (req.body && req.body.message) ? String(req.body.message) : '';
    const message = rawMessage.trim().slice(0, 400);
    if (!message) {
        return res.status(400).json({ success: false, reply: 'Please type a question or describe what you need help with.' });
    }

    const text = message.toLowerCase();
    let reply = 'I am the Capital Pool support bot. I can answer questions about tickets, winners, cashback, profile setup, payments, and site security.';

    if (/grand prize|grand winner|25,000,000|25 million|grand/.test(text)) {
        reply = 'The grand prize is the main weekly award. One ticket wins the ₦25,000,000 prize once the draw runs. If your ticket is the grand winner, the system marks it gold and you will be asked to complete profile details for payout contact.';
    } else if (/secondary winner|secondary winners|secondary|ledger/.test(text)) {
        reply = 'Secondary winners are additional qualifying tickets that are published in the Transparency Ledger. Their status is silver, and they receive the secondary reward. The public ledger shows these secondary winners to keep the draw transparent.';
    } else if (/cashback|refund|50%|2,500|safety|protection/.test(text)) {
        reply = 'Every ticket purchase includes a 50% cashback protection. If your ticket is not selected, half of the ticket cost is credited back to your wallet automatically. That makes the platform safer than typical entry-only systems.';
    } else if (/ticket|purchase|buy|entry/.test(text)) {
        reply = 'Tickets are bought through the Secure Entry Portal. Each ticket costs ₦5,000. After payment, your ticket is saved with a unique code and participates in the weekly draw.';
    } else if (/profile|additional information|bank|university|phone/.test(text)) {
        reply = 'Fill in your additional profile information in the dashboard so we can reach you if your ticket is selected. This includes your full name, phone, university, and bank details when needed for payment.';
    } else if (/support|help|chatbot|bot/.test(text)) {
        reply = 'You are chatting with the Capital Pool mini AI support bot. Ask it about grand prize rules, secondary winners, how cashback works, or how to complete your ticket and profile.';
    } else if (/secure|safe|hack|hacked|security|manipulate/.test(text)) {
        reply = 'Capital Pool uses built-in security headers, rate limiting, secure server routing, and session protections. All sensitive user data and ticket entries are stored carefully and protected from direct manipulation.';
    } else if (/payment|paystack|bank transfer|card/.test(text)) {
        reply = 'Payment happens through the secure checkout page and support page. For bank transfer, use the fixed settlement account details. For card payments, the system routes through a secure payment gateway.';
    } else {
        reply = 'I understand Capital Pool ticket entries, the grand prize and secondary winner system, the transparency ledger, cashback, profile steps, and secure site operation. Ask me another question with any of those topics.';
    }

    return res.json({ success: true, reply });
});

// GET winners history (all cycles)
app.get('/api/winners', (req, res) => {
    const historyFile = path.join(DATA_FOLDER, 'selection_history.json');
    try {
        if (!fs.existsSync(historyFile)) return res.json({ success: true, history: [] });
        const raw = fs.readFileSync(historyFile, 'utf8') || '[]';
        const data = JSON.parse(raw);
        return res.json({ success: true, history: data });
    } catch (err) {
        console.error('Failed to read winners history:', err);
        return res.status(500).json({ success: false, message: 'Failed to load winners history.' });
    }
});

// GET winners for a specific cycle (by cycle code)
app.get('/api/winners/:cycle', (req, res) => {
    const cycle = req.params.cycle;
    const historyFile = path.join(DATA_FOLDER, 'selection_history.json');
    try {
        if (!fs.existsSync(historyFile)) return res.status(404).json({ success: false, message: 'No selection history found.' });
        const raw = fs.readFileSync(historyFile, 'utf8') || '[]';
        const data = JSON.parse(raw);
        const found = data.find(item => item.cycle === cycle);
        if (!found) return res.status(404).json({ success: false, message: 'Cycle not found.' });
        return res.json({ success: true, selection: found });
    } catch (err) {
        console.error('Failed to read winners history for cycle:', err);
        return res.status(500).json({ success: false, message: 'Failed to load cycle winners.' });
    }
});

app.listen(PORT, () => {
    console.log(`===================================================`);
    console.log(`🚀 CAPITAL POOL TERMINAL BACKEND RUNNING SUCCESS`);
    console.log(`📡 Local Environment Node: http://localhost:${PORT}`);
    console.log(`===================================================`);
});
