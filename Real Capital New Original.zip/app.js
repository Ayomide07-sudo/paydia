
// ============================================================
// app.js – COMPLETE FRONTEND LOGIC (All Pages Consolidated)
// Fully backend‑ready – no localStorage used
// ============================================================
document.addEventListener('DOMContentLoaded', function() {

    // ============================================================
    // PART 0: UNIVERSAL NAVIGATION SYNC (All Pages)
    // ============================================================
    function syncNavButton() {
        const portalBtn = document.getElementById('nav-portal-btn');
        if (!portalBtn) return;
        fetch('/api/auth/status')
            .then(r => r.json())
            .then(session => {
                if (session.loggedIn) {
                    let name = session.firstName ? session.firstName.toLowerCase() : 'node';
                    portalBtn.href = 'dashboard.html';
                    portalBtn.textContent = `Dashboard (@${name})`;
                    portalBtn.style.backgroundColor = '#ffab00';
                    portalBtn.style.color = '#000';
                    portalBtn.style.fontWeight = 'bold';
                } else {
                    // Ensure it points to portal if not logged in
                    portalBtn.href = 'portal.html';
                    portalBtn.textContent = 'Secure Entry Portal';
                    portalBtn.style.backgroundColor = '';
                    portalBtn.style.color = '';
                    portalBtn.style.fontWeight = '';
                }
            })
            .catch(() => {});
    }
    syncNavButton();

    // ============================================================
    // PART 1: TIMER & LEDGER
    // ============================================================
    const CURRENT_CYCLE_ID = 1;
    function getLiveCycleMetrics(currentTime) {
        return { cycleId: `#CP-0${CURRENT_CYCLE_ID}`, winnerName: "Awaiting Saturday draw" };
    }

    function runEcosystemTimer() {
        const hoursEl = document.getElementById('timer-hours');
        const minutesEl = document.getElementById('timer-minutes');
        const secondsEl = document.getElementById('timer-seconds');
        const displayBox = document.getElementById('timer-display-box');
        const announcementBlock = document.getElementById('winner-announcement-block');
        const dynamicWinnerNameEl = document.getElementById('dynamic-winner-name');
        const cycleLabelEl = document.getElementById('current-cycle-label');

        if (!hoursEl) return;
        const now = new Date();
        const metrics = getLiveCycleMetrics(now);
        const satTarget = new Date(now);
        const currentDay = now.getDay();
        const daysToSaturday = (6 - currentDay + 7) % 7;
        satTarget.setDate(now.getDate() + daysToSaturday);
        satTarget.setHours(20, 0, 0, 0);
        const sunTarget = new Date(satTarget);
        sunTarget.setDate(satTarget.getDate() + 1);
        sunTarget.setHours(0, 0, 0, 0);

        if (currentDay === 6 && now.getHours() >= 20) {
            if (now < sunTarget) {
                if (displayBox) displayBox.style.display = "none";
                if (announcementBlock) { announcementBlock.style.display = "block"; if (dynamicWinnerNameEl) dynamicWinnerNameEl.textContent = metrics.winnerName; }
                if (cycleLabelEl) cycleLabelEl.textContent = metrics.cycleId;
                return;
            } else { satTarget.setDate(satTarget.getDate() + 7); }
        } else if (currentDay === 0) { satTarget.setDate(now.getDate() + 6); satTarget.setHours(20, 0, 0, 0); }

        if (displayBox) displayBox.style.display = "flex";
        if (announcementBlock) announcementBlock.style.display = "none";
        if (cycleLabelEl) cycleLabelEl.textContent = metrics.cycleId;

        const delta = satTarget.getTime() - now.getTime();
        if (delta <= 0) { hoursEl.textContent = "00"; minutesEl.textContent = "00"; secondsEl.textContent = "00"; return; }
        const h = Math.floor(delta / (1000 * 60 * 60));
        const m = Math.floor((delta % (1000 * 60 * 60)) / (1000 * 60));
        const s = Math.floor((delta % (1000 * 60)) / 1000);
        hoursEl.textContent = h < 10 ? "0" + h : h;
        minutesEl.textContent = m < 10 ? "0" + m : m;
        secondsEl.textContent = s < 10 ? "0" + s : s;
    }

    function updateLedgerTableRecords() {
        const pendingRowCycle = document.getElementById('pending-row-cycle');
        const pendingRowWinner = document.getElementById('pending-row-winner');
        const pendingRowStatus = document.getElementById('pending-row-status');
        const pendingRowFunds = document.getElementById('pending-row-funds');
        const pendingRowCashback = document.getElementById('pending-row-cashback');
        if (!pendingRowCycle) return;
        const now = new Date();
        const metrics = getLiveCycleMetrics(now);
        const satTarget = new Date(now);
        satTarget.setDate(now.getDate() + (6 - now.getDay() + 7) % 7);
        satTarget.setHours(20, 0, 0, 0);
        const sunTarget = new Date(satTarget);
        sunTarget.setDate(satTarget.getDate() + 1);
        sunTarget.setHours(0, 0, 0, 0);

        if (now >= satTarget && now < sunTarget) {
            if (pendingRowCycle) pendingRowCycle.innerHTML = `<strong>${metrics.cycleId}</strong>`;
            if (pendingRowWinner) pendingRowWinner.textContent = metrics.winnerName;
            if (pendingRowFunds) { pendingRowFunds.textContent = "₦25,000,000"; pendingRowFunds.className = "gold-text"; }
            if (pendingRowCashback) { pendingRowCashback.textContent = "₦13,150,000 (100%)"; pendingRowCashback.className = "green-text"; }
            if (pendingRowStatus) pendingRowStatus.innerHTML = `<span class="status-badge-complete">✓ Settled</span>`;
            const pRow = document.querySelector('.ledger-row[data-status="pending"]');
            if (pRow) pRow.setAttribute('data-status', 'settled');
        } else {
            if (pendingRowCycle) pendingRowCycle.innerHTML = `<strong>${metrics.cycleId}</strong>`;
            if (pendingRowWinner) pendingRowWinner.textContent = "Waiting for selection...";
            if (pendingRowFunds) { pendingRowFunds.textContent = "Calculating..."; pendingRowFunds.className = "light-text"; }
            if (pendingRowCashback) { pendingRowCashback.textContent = "Pending Draw"; pendingRowCashback.className = "light-text"; }
            if (pendingRowStatus) pendingRowStatus.innerHTML = `<span class="status-badge-pending">⌛ Processing</span>`;
        }
    }

    // ============================================================
    // PART 2: PORTAL AUTHENTICATION (FULLY BACKEND SESSION)
    // ============================================================
    const signupForm = document.getElementById('signup-form-view')?.querySelector('form');
    const loginForm = document.getElementById('login-form-view')?.querySelector('form');
    const verifyForm = document.getElementById('verify-form-view')?.querySelector('form');

    // --- Tab switching: attach listeners to tabs ---
    const tabSignup = document.getElementById('tab-signup');
    const tabLogin = document.getElementById('tab-login');

    window.toggleAuthView = function(view) {
        const signup = document.getElementById('signup-form-view');
        const login = document.getElementById('login-form-view');
        const verify = document.getElementById('verify-form-view');
        const tabS = document.getElementById('tab-signup');
        const tabL = document.getElementById('tab-login');
        if (signup) signup.style.display = 'none';
        if (login) login.style.display = 'none';
        if (verify) verify.style.display = 'none';
        if (view === 'signup') {
            if (signup) signup.style.display = 'block';
            if (tabS) { tabS.classList.add('active'); tabS.classList.remove('inactive'); }
            if (tabL) { tabL.classList.remove('active'); tabL.classList.add('inactive'); }
        } else if (view === 'verify') {
            if (verify) verify.style.display = 'block';
            if (tabS) { tabS.classList.remove('active'); tabS.classList.add('inactive'); }
            if (tabL) { tabL.classList.remove('active'); tabL.classList.add('inactive'); }
        } else { // login
            if (login) login.style.display = 'block';
            if (tabL) { tabL.classList.add('active'); tabL.classList.remove('inactive'); }
            if (tabS) { tabS.classList.remove('active'); tabS.classList.add('inactive'); }
        }
    };

    // Attach tab click listeners
    if (tabSignup) {
        tabSignup.addEventListener('click', function() {
            window.toggleAuthView('signup');
        });
    }
    if (tabLogin) {
        tabLogin.addEventListener('click', function() {
            window.toggleAuthView('login');
        });
    }

    // --- Sign Up ---
    if (signupForm) {
        signupForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const payload = {
                firstName: document.getElementById('reg-firstname').value.trim(),
                phone: document.getElementById('reg-phone').value.trim(),
                email: document.getElementById('reg-email').value.trim().toLowerCase(),
                password: document.getElementById('reg-password').value
            };
            fetch('/api/auth/signup', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        alert('📧 Verification code sent to your email.');
                        document.getElementById('verify-email').value = payload.email;
                        window.toggleAuthView('verify');
                    } else {
                        alert('❌ ' + data.message);
                    }
                })
                .catch(() => alert('❌ Server connection error.'));
        });
    }

    // --- Verify Code ---
    if (verifyForm) {
        verifyForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = document.getElementById('verify-email').value.trim().toLowerCase();
            const code = document.getElementById('verify-code').value.trim();
            fetch('/api/auth/verify-code', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, code }) })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        alert('✅ Verified! Please login.');
                        window.toggleAuthView('login');
                    } else {
                        alert('❌ ' + data.message);
                    }
                });
        });
    }

    // --- Resend Code ---
    const resendBtn = document.getElementById('resend-code-btn');
    window.handleResendCode = function() {
        const email = document.getElementById('verify-email').value.trim().toLowerCase();
        if (!email) return alert('Enter your email.');
        fetch('/api/auth/resend-code', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email }) })
            .then(r => r.json())
            .then(data => alert(data.success ? '📧 New code sent!' : '❌ ' + data.message));
    };
    if (resendBtn) {
        resendBtn.addEventListener('click', window.handleResendCode);
    }

    // --- Login ---
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = document.getElementById('log-email').value.trim().toLowerCase();
            const password = document.getElementById('log-password').value;
            fetch('/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password }) })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        // Session is set via HttpOnly cookie; no localStorage needed
                        window.location.href = 'dashboard.html';
                    } else if (data.message && data.message.toLowerCase().includes('verify')) {
                        document.getElementById('verify-email').value = email;
                        window.toggleAuthView('verify');
                    } else {
                        alert('❌ ' + data.message);
                    }
                });
        });
    }

    // ============================================================
    // PART 3: FORGOT PASSWORD (Simplified – email once)
    // ============================================================
    const resetRequestForm = document.getElementById('reset-request-form');
    const resetConfirmForm = document.getElementById('reset-confirm-form');
    let resetEmail = '';

    if (resetRequestForm) {
        resetRequestForm.addEventListener('submit', function(e) {
            e.preventDefault();
            resetEmail = document.getElementById('reset-email').value.trim().toLowerCase();
            if (!resetEmail) return;

            fetch('/api/auth/request-password-reset', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: resetEmail }) })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        alert('📧 Reset code sent to your email.');
                        document.getElementById('reset-step-1').style.display = 'none';
                        document.getElementById('reset-step-2').style.display = 'block';
                    } else {
                        alert('❌ ' + data.message);
                    }
                })
                .catch(() => alert('❌ Server error.'));
        });
    }

    if (resetConfirmForm) {
        resetConfirmForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const code = document.getElementById('reset-code').value.trim();
            const newPassword = document.getElementById('reset-new-password').value;
            if (!resetEmail || !code || !newPassword) return;

            fetch('/api/auth/reset-password', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: resetEmail, code, newPassword }) })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        alert('✅ Password reset! You can now login.');
                        window.location.href = 'portal.html';
                    } else {
                        alert('❌ ' + data.message);
                    }
                });
        });
    }

    // ============================================================
    // PART 4: DASHBOARD
    // ============================================================
    let activeUserObject = null;
    let liveSettledCashbackBalance = 0;

    function lockAndDisplayProfileFields(details) {
        if (!details) return;
        const form = document.getElementById('profile-terminal-form');
        if (!form) return;
        form.querySelectorAll('input, select').forEach(el => { el.disabled = true; el.style.opacity = '0.6'; });
        const btn = document.getElementById('profile-save-btn');
        if (btn) { btn.disabled = true; btn.innerHTML = '✓ Synced & Locked'; btn.style.background = '#1e3a63'; }
        const badge = document.getElementById('profile-status-badge');
        if (badge) { badge.textContent = '✓ Profile Complete'; badge.className = 'meta-tag green-tag'; badge.style.background = '#00ffcc'; badge.style.color = '#111'; }
        document.getElementById('profile-fullname').value = details.fullName || '';
        document.getElementById('profile-phone').value = details.phone || '';
        document.getElementById('profile-university').value = details.university || '';
        document.getElementById('profile-preference').value = details.preference || '';
        if (details.preference === 'money') {
            document.getElementById('bank-routing-details-block').style.display = 'block';
            document.getElementById('profile-bank-name').value = details.bankName || '';
            document.getElementById('profile-account-number').value = details.accountNumber || '';
        }
    }

    window.toggleBankFieldsValue = function(selectedValue) {
        const bankBlock = document.getElementById('bank-routing-details-block');
        const bankInput = document.getElementById('profile-bank-name');
        const accountInput = document.getElementById('profile-account-number');
        if (!bankBlock) return;
        if (selectedValue === 'money') {
            bankBlock.style.display = 'block';
            if (bankInput) bankInput.setAttribute('required', 'true');
            if (accountInput) accountInput.setAttribute('required', 'true');
        } else {
            bankBlock.style.display = 'none';
            if (bankInput) bankInput.removeAttribute('required');
            if (accountInput) accountInput.removeAttribute('required');
        }
    };

    function updateEcosystemWalletBalances() {
        let aggregatedActiveStake = 0, aggregatedSettledCashback = 0, isGrandWinnerUnlocked = false;
        if (!activeUserObject || !activeUserObject.ticketHistory || activeUserObject.ticketHistory.length === 0) {
            document.getElementById('top-total-display').textContent = "₦0.00";
            document.getElementById('top-cashback-display').textContent = "₦0.00";
            document.getElementById('top-grant-display').textContent = "₦0.00";
            const stakingStatusTag = document.getElementById('staking-status-tag');
            if (stakingStatusTag) { stakingStatusTag.textContent = "No Tickets Purchased"; stakingStatusTag.className = "meta-tag orange-tag"; }
            liveSettledCashbackBalance = 0;
            calculateEcosystemStaking(document.getElementById('ticket-range')?.value || 1);
            return;
        }
        activeUserObject.ticketHistory.forEach(ticket => {
            const rawCostValue = ticket.rawCost || parseInt(ticket.cost.replace(/[^0-9]/g, '')) || 0;
            const rawPaybackValue = ticket.rawPayback || parseInt(ticket.payback.replace(/[^0-9]/g, '')) || 0;
            if (["Pending Sync", "Active Tracking", "Pending Verification"].includes(ticket.status)) aggregatedActiveStake += rawCostValue;
            else if (["Refunded", "Not Selected", "Lost"].includes(ticket.status)) aggregatedSettledCashback += rawPaybackValue;
            else if (["Selected", "Beneficiary", "Grand Winner"].includes(ticket.status)) { isGrandWinnerUnlocked = true; aggregatedSettledCashback += rawPaybackValue; }
        });
        liveSettledCashbackBalance = aggregatedSettledCashback;
        document.getElementById('top-total-display').textContent = "₦" + aggregatedActiveStake.toLocaleString() + ".00";
        document.getElementById('top-cashback-display').textContent = "₦" + aggregatedSettledCashback.toLocaleString() + ".00";
        const stakingStatusTag = document.getElementById('staking-status-tag');
        if (stakingStatusTag) {
            if (aggregatedActiveStake > 0) { stakingStatusTag.textContent = "Node Active in Cycle"; stakingStatusTag.className = "meta-tag blue-tag"; }
            else { stakingStatusTag.textContent = "Inactive Node"; stakingStatusTag.className = "meta-tag orange-tag"; }
        }
        if (isGrandWinnerUnlocked) {
            document.getElementById('top-grant-display').textContent = "₦25,000,000.00";
            const grantStatus = document.getElementById('grant-status-tag');
            if (grantStatus) { grantStatus.textContent = "✓ Disbursed to Account"; grantStatus.className = "meta-tag green-tag"; }
        } else {
            document.getElementById('top-grant-display').textContent = "₦0.00";
        }
        calculateEcosystemStaking(document.getElementById('ticket-range')?.value || 1);
    }

    window.calculateEcosystemStaking = function(value) {
        const ticketRange = document.getElementById('ticket-range');
        if (!ticketRange) return;
        value = parseInt(value) || 1;
        const label = document.getElementById('ticket-count-label');
        if (label) label.textContent = value;
        const total = value * 5000;
        const cash = value * 2500;
        let payable = total - (liveSettledCashbackBalance || 0);
        if (payable < 0) payable = 0;
        document.getElementById('calc-stake-total').textContent = '₦' + total.toLocaleString();
        document.getElementById('calc-cashback-total').textContent = '₦' + cash.toLocaleString();
        const link = document.getElementById('dynamic-payment-link');
        if (link) link.href = `payment.html?shares=${value}&final_amount=${payable}`;
        const btnAmt = document.getElementById('btn-dynamic-amount');
        if (btnAmt) btnAmt.textContent = '₦' + payable.toLocaleString();
    };

    window.switchDashboardVideo = function(event) {
        const targetId = event.currentTarget.getAttribute('data-target');
        document.querySelectorAll('.dashboard-video-section .video-tab').forEach(btn => {
            btn.classList.toggle('active', btn.getAttribute('data-target') === targetId);
            btn.style.backgroundColor = btn.getAttribute('data-target') === targetId ? '#ffab00' : '#111';
            btn.style.color = btn.getAttribute('data-target') === targetId ? '#111' : '#ffab00';
        });
        document.querySelectorAll('.dashboard-video-section .video-panel').forEach(panel => {
            panel.style.display = panel.id === targetId ? 'block' : 'none';
        });
    };

    window.handleSignOut = function() {
        if (confirm("Are you sure you want to terminate this secure terminal session?")) {
            fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin' })
                .then(() => {
                    alert("Session closed safely.");
                    window.location.href = 'portal.html';
                })
                .catch(() => alert("Error terminating session."));
        }
    };

    // Dashboard Load
    const profileForm = document.getElementById('profile-terminal-form');
    if (profileForm) {
        // Security gate
        fetch('/api/auth/status').then(r => r.json()).then(session => {
            if (!session.loggedIn) { alert("🔒 Access Denied."); window.location.href = 'portal.html'; }
        }).catch(() => window.location.href = 'portal.html');

        fetch('/api/user/profile').then(r => r.json()).then(data => {
            if (!data.success) { alert("⚠️ Session expired."); window.location.href = 'portal.html'; return; }
            activeUserObject = data;
            document.getElementById('welcome-user-heading').textContent = "Welcome, " + activeUserObject.firstName;
            document.getElementById('header-user-badge').textContent = "@" + activeUserObject.firstName.toLowerCase() + " (Active Node)";
            if (activeUserObject.profileCompleted) lockAndDisplayProfileFields(activeUserObject.profileDetails);
            updateEcosystemWalletBalances();
            fetch('/api/selection/recent').then(r => r.json()).then(sel => {
                if (sel && sel.success && sel.selection) {
                    const nameEl = document.getElementById('dynamic-winner-name');
                    if (nameEl && sel.selection.grand) nameEl.textContent = sel.selection.grand.nodeCode || sel.selection.grand.email || sel.selection.grand.firstName || '—';
                }
            }).catch(() => {});
        }).catch(err => { console.error(err); alert("❌ Communication Fault."); });

        profileForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const profileData = {
                fullName: document.getElementById('profile-fullname').value,
                phone: document.getElementById('profile-phone').value,
                university: document.getElementById('profile-university').value,
                preference: document.getElementById('profile-preference').value,
                bankName: document.getElementById('profile-bank-name').value || null,
                accountNumber: document.getElementById('profile-account-number').value || null
            };
            fetch('/api/user/update-profile', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(profileData) })
                .then(r => r.json())
                .then(res => { if (res.success) { alert("✅ Profile saved!"); lockAndDisplayProfileFields(profileData); } else alert("❌ " + res.message); });
        });

        document.getElementById('profile-preference')?.addEventListener('change', function() {
            window.toggleBankFieldsValue(this.value);
        });

        const ticketRange = document.getElementById('ticket-range');
        if (ticketRange) {
            ticketRange.addEventListener('input', function() { calculateEcosystemStaking(this.value); });
        }
    }

    // ============================================================
    // PART 5: PAYMENT PAGE (No localStorage)
    // ============================================================
    const checkoutMain = document.getElementById('main-checkout-interface');
    if (checkoutMain) {
        let entryShares = 1, totalCostAmount = 5000, totalProtectionRefund = 2500, activeGatewayMode = "transfer", countdownTimerReference;
        let sessionExpiry = 0; // in seconds since epoch

        const params = new URLSearchParams(window.location.search);
        const rawShares = parseInt(params.get('shares')) || 1;
        entryShares = Math.min(Math.max(rawShares, 1), 10);
        totalCostAmount = entryShares * 5000;
        totalProtectionRefund = entryShares * 2500;

        document.getElementById('checkout-amount-display').textContent = "₦" + totalCostAmount.toLocaleString() + ".00";
        document.getElementById('instruction-amount-text').textContent = "₦" + totalCostAmount.toLocaleString();
        document.getElementById('cashback-notice-amount').textContent = "₦" + totalProtectionRefund.toLocaleString();
        document.getElementById('checkout-shares-badge').textContent = entryShares + " Entry Share(s) Active";

        fetch('/api/auth/status').then(r => r.json()).then(status => {
            if (!status.loggedIn) { alert('🔒 Please login.'); window.location.href = 'portal.html'; }
        }).catch(() => window.location.href = 'portal.html');

        window.switchGatewayView = function(targetMode) {
            activeGatewayMode = targetMode;
            const tabTransfer = document.getElementById('tab-transfer');
            const tabCard = document.getElementById('tab-card');
            const viewTransfer = document.getElementById('view-gateway-transfer');
            const viewCard = document.getElementById('view-gateway-card');
            if (targetMode === 'transfer') {
                tabTransfer.classList.add('active-method');
                tabCard.classList.remove('active-method');
                viewTransfer.style.display = 'block';
                viewCard.style.display = 'none';
            } else {
                tabCard.classList.add('active-method');
                tabTransfer.classList.remove('active-method');
                viewCard.style.display = 'block';
                viewTransfer.style.display = 'none';
            }
        };

        function initSessionTimer() {
            // Set expiry 10 minutes from now
            sessionExpiry = Math.floor(Date.now() / 1000) + 600;
            function update() {
                const secs = sessionExpiry - Math.floor(Date.now() / 1000);
                if (secs <= 0) {
                    clearInterval(countdownTimerReference);
                    alert("Session expired. Returning to dashboard.");
                    window.location.href = 'dashboard.html';
                    return;
                }
                const m = Math.floor(secs / 60), s = secs % 60;
                document.getElementById('session-clock').textContent = `${m<10?'0':''}${m}:${s<10?'0':''}${s}`;
            }
            update();
            countdownTimerReference = setInterval(update, 1000);
        }
        initSessionTimer();

        window.terminateSessionManually = function() {
            clearInterval(countdownTimerReference);
            window.location.href = 'dashboard.html';
        };
        window.returnToDashboardTerminal = function() {
            clearInterval(countdownTimerReference);
            window.location.href = 'dashboard.html?verification_sync=initialized&shares_bought=' + entryShares;
        };

        window.initializeProcessingPipeline = function() {
            if (activeGatewayMode === 'card') {
                const email = document.getElementById('checkout-card-email').value;
                if (!email || !email.includes('@')) { alert("Please enter a valid email."); return; }
            }
            clearInterval(countdownTimerReference);
            document.getElementById('main-checkout-interface').style.display = "none";
            document.getElementById('processing-gateway-overlay').style.display = "flex";
            const log = document.getElementById('audit-log-stream');
            setTimeout(() => log.innerHTML += "<br>[OK] Transaction signature captured...", 1000);
            setTimeout(() => log.innerHTML += "<br>[SYNC] Parsing ledger data...", 2200);
            setTimeout(() => log.innerHTML += "<br>[WARN] Resolving network parameters...", 3500);
            setTimeout(() => {
                log.innerHTML += "<br>[STATUS] Pipeline mapped. Generating ticket...";
                fetch('/api/tickets/generate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ shares: entryShares, cost: totalCostAmount }) })
                    .then(r => r.json())
                    .then(data => {
                        if (data.success) alert('Payment processed and ticket generated.');
                        else alert('Server accepted payment but failed to save ticket: ' + data.message);
                        window.returnToDashboardTerminal();
                    })
                    .catch(() => { alert('Payment recorded locally, but backend save failed.'); window.returnToDashboardTerminal(); });
            }, 4500);
        };

        document.getElementById('tab-transfer').addEventListener('click', function() { window.switchGatewayView('transfer'); });
        document.getElementById('tab-card').addEventListener('click', function() { window.switchGatewayView('card'); });
        document.querySelector('.checkout-success-btn')?.addEventListener('click', window.initializeProcessingPipeline);
        document.querySelector('.cancel-transaction-link')?.addEventListener('click', window.terminateSessionManually);
    }

    // ============================================================
    // PART 6: TICKETS VAULT
    // ============================================================
    const vaultWrapper = document.getElementById('vault-records-wrapper');
    if (vaultWrapper) {
        let activeUser = null;
        fetch('/api/auth/status').then(r => r.json()).then(session => {
            if (!session.loggedIn) { alert("🔒 Access Denied."); window.location.href = 'portal.html'; }
        }).catch(() => window.location.href = 'portal.html');

        function renderVault() {
            const wrapper = document.getElementById('vault-records-wrapper');
            const fallback = document.getElementById('empty-vault-fallback');
            const activeContainer = document.getElementById('active-tickets-container');
            const pastContainer = document.getElementById('past-tickets-container');
            if (!activeUser || !activeUser.ticketHistory || activeUser.ticketHistory.length === 0) {
                wrapper.style.display = "none";
                fallback.style.display = "block";
                return;
            }
            wrapper.style.display = "block";
            fallback.style.display = "none";
            activeContainer.innerHTML = '';
            pastContainer.innerHTML = '';
            let activeCount = 0, pastCount = 0;
            activeUser.ticketHistory.forEach(ticket => {
                const normalizedStatus = (ticket.status || '').trim().toLowerCase();
                const isActive = ['pending sync', 'active tracking', 'pending verification', 'processing'].includes(normalizedStatus);
                let dynamicStatus = ticket.status || 'Unknown';
                if (['refunded', 'not selected', 'lost'].includes(normalizedStatus)) dynamicStatus = 'Lost';
                else if (normalizedStatus === 'grand winner') dynamicStatus = 'Grand Prize Winner';
                else if (normalizedStatus === 'secondary winner') dynamicStatus = 'Secondary Winner';
                const cssClass = normalizedStatus.replace(/\s+/g, '-') || 'unknown';
                const code = ticket.nodeCode || Math.floor(100000000 + Math.random() * 900000000).toString();
                const html = `
                    <div class="rectangular-ticket">
                        <div class="ticket-details">
                            <div class="ticket-row-main"><span class="ticket-cycle-id">${ticket.cycle}</span><span class="ticket-status-pill status-${cssClass}">${dynamicStatus}</span></div>
                            <p>Date: <strong>${ticket.date}</strong></p>
                            <p>Shares: <strong>${ticket.shares}</strong></p>
                            <p>Cost: <strong>${ticket.cost}</strong></p>
                            <p>Cashback Margin: <strong>${ticket.payback}</strong></p>
                            ${ticket.winnerTier ? `<p>Tier: <strong>${ticket.winnerTier}</strong></p>` : ''}
                            ${ticket.prize ? `<p>Prize: <strong>${ticket.prize}</strong></p>` : ''}
                            ${ticket.prizeMessage ? `<p class="ticket-note">${ticket.prizeMessage}</p>` : ''}
                            ${ticket.requireProfile ? `<p class="ticket-note warning-note">Please complete your additional information.</p>` : ''}
                        </div>
                        <div class="ticket-code-section"><span class="code-lbl">9-Digit Selection Code</span><span class="code-num">${code}</span></div>
                    </div>`;
                if (isActive) { activeContainer.innerHTML += html; activeCount++; } else { pastContainer.innerHTML += html; pastCount++; }
            });
            if (activeCount === 0) activeContainer.innerHTML = `<p class="no-tickets-msg">No active tickets for this cycle.</p>`;
            if (pastCount === 0) pastContainer.innerHTML = `<p class="no-tickets-msg">No historical tickets found.</p>`;
        }

        fetch('/api/user/profile').then(r => r.json()).then(data => {
            if (!data.success) { alert("⚠️ Session expired."); window.location.href = 'portal.html'; return; }
            activeUser = data;
            document.getElementById('vault-node-title').textContent = "Node: @" + activeUser.firstName.toLowerCase();
            renderVault();
        });
    }

    // ============================================================
    // PART 7: WINNERS DATABASE
    // ============================================================
    const winnersContent = document.getElementById('winners-content');
    if (winnersContent) {
        function formatProfile(details) {
            if (!details || Object.keys(details).length === 0) return '<p class="ticket-note warning-note">Additional information is not complete.</p>';
            return `<p><strong>Full Name:</strong> ${details.fullName || 'N/A'}</p><p><strong>Phone:</strong> ${details.phone || 'N/A'}</p><p><strong>University:</strong> ${details.university || 'N/A'}</p>${details.preference === 'money' ? `<p><strong>Bank:</strong> ${details.bankName || 'N/A'}</p><p><strong>Account:</strong> ${details.accountNumber || 'N/A'}</p>` : ''}`;
        }

        function renderCycle(item) {
            const grand = item.grand;
            const secondary = (item.secondary || []).map((w, i) => `
                <div class="rectangular-ticket" style="flex-direction:column; align-items:flex-start; gap:8px;">
                    <div class="ticket-row-main"><span class="ticket-cycle-id">Secondary #${i+1}</span><span class="ticket-status-pill status-secondary-winner">Secondary Winner</span></div>
                    <p><strong>Node:</strong> ${w.nodeCode || '—'}</p><p><strong>Email:</strong> ${w.email || '—'}</p><p><strong>Phone:</strong> ${w.phone || '—'}</p><p><strong>Prize:</strong> ${w.prize || '₦500,000'}</p>
                    <p><strong>Profile Completed:</strong> ${w.profileCompleted ? 'Yes' : 'No'}</p>${formatProfile(w.profileDetails)}
                </div>`).join('');
            return `<div class="interface-card data-card mb-20" style="padding:20px; background:#07172e; border:1px solid #1f3861;">
                <div style="display:grid; gap:16px;">
                    <div style="display:flex; justify-content:space-between; flex-wrap:wrap;"><span class="ticket-cycle-id">Cycle ${item.cycle}</span><span class="ticket-status-pill status-grand-winner">Grand Winner Archive</span></div>
                    <p><strong>Draw Date:</strong> ${item.date || 'Unknown'}</p>
                    <div class="rectangular-ticket" style="flex-direction:column; align-items:flex-start; gap:8px;">
                        <div class="ticket-row-main"><span class="ticket-cycle-id">Grand Winner</span><span class="ticket-status-pill status-grand-winner">Grand</span></div>
                        <p><strong>Node:</strong> ${grand.nodeCode || '—'}</p><p><strong>Email:</strong> ${grand.email || '—'}</p><p><strong>Phone:</strong> ${grand.phone || '—'}</p><p><strong>Prize:</strong> ${grand.prize || '₦25,000,000'}</p>
                        <p><strong>Profile Completed:</strong> ${grand.profileCompleted ? 'Yes' : 'No'}</p>${formatProfile(grand.profileDetails)}
                    </div>
                    <div><h4 style="margin-bottom:10px;">Secondary winners</h4>${secondary || '<p class="ticket-note">None selected.</p>'}</div>
                </div>
            </div>`;
        }

        fetch('/api/winners').then(r => r.json()).then(data => {
            if (!data.success || !data.history || data.history.length === 0) {
                document.getElementById('no-winners-state').style.display = 'block';
                return;
            }
            data.history.forEach(item => { winnersContent.innerHTML += renderCycle(item); });
        }).catch(() => { document.getElementById('no-winners-state').style.display = 'block'; });
    }

    // ============================================================
    // PART 8: SUPPORT CHAT
    // ============================================================
    const chatWindow = document.getElementById('chatWindow');
    if (chatWindow) {
        function appendMsg(author, text) {
            const div = document.createElement('div');
            div.className = `chat-message ${author}`;
            div.innerHTML = `<div class="bubble">${text}</div>`;
            chatWindow.appendChild(div);
            chatWindow.scrollTop = chatWindow.scrollHeight;
        }
        window.sendSupportMessage = function() {
            const input = document.getElementById('supportMessageInput');
            const msg = input.value.trim();
            if (!msg) return;
            appendMsg('user', msg);
            input.value = '';
            appendMsg('bot', 'Connecting to backend...');
            fetch('/api/support/message', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: msg }) })
                .then(r => r.json())
                .then(data => { chatWindow.querySelector('.chat-message.bot:last-child')?.remove(); appendMsg('bot', data.reply || 'No response.'); })
                .catch(() => { chatWindow.querySelector('.chat-message.bot:last-child')?.remove(); appendMsg('bot', 'Unable to reach support.'); });
        };
        document.getElementById('supportSendBtn')?.addEventListener('click', window.sendSupportMessage);
        document.getElementById('supportMessageInput')?.addEventListener('keypress', (e) => { if (e.key === 'Enter') window.sendSupportMessage(); });
        appendMsg('bot', 'Hi! Ask me about tickets, payouts, or account access.');
    }

    // ============================================================
    // PART 9: BENEFACTORS SLIDESHOW TABS
    // ============================================================
    document.querySelectorAll('.slide-tabs .tab-btn[data-slide]').forEach(btn => {
        btn.addEventListener('click', function() {
            const idx = this.dataset.slide;
            document.querySelectorAll('.slide-tabs .tab-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            document.querySelectorAll('.tier-slide').forEach(s => s.classList.remove('active'));
            const slides = document.querySelectorAll('.tier-slide');
            if (slides[idx]) slides[idx].classList.add('active');
        });
    });

    // ============================================================
    // PART 10: HOMEPAGE CAROUSEL, METRICS, POPUP
    // ============================================================
    const track = document.getElementById('carouselTrack');
    const nextBtn = document.getElementById('nextBtn');
    const prevBtn = document.getElementById('prevBtn');
    if (track && nextBtn) {
        let idx = 0;
        function updateCarousel() {
            const card = track.querySelector('.carousel-slide-card');
            if (!card) return;
            const width = card.offsetWidth + 24;
            track.style.transform = `translateX(-${idx * width}px)`;
        }
        nextBtn.addEventListener('click', () => {
            const total = track.children.length;
            const max = window.innerWidth > 768 ? total - 2 : total - 1;
            idx = idx < max ? idx + 1 : 0;
            updateCarousel();
        });
        if (prevBtn) prevBtn.addEventListener('click', () => { idx = idx > 0 ? idx - 1 : 0; updateCarousel(); });
        window.addEventListener('resize', updateCarousel);
        setInterval(() => nextBtn.click(), 5000);
    }

    // Metric Counter
    function animateValue(id, start, end, duration, isCurrency, isPercent) {
        const obj = document.getElementById(id);
        if (!obj) return;
        let startTimestamp = null;
        const step = (timestamp) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
            const currentVal = Math.floor(progress * (end - start) + start);
            if (isPercent) obj.innerHTML = currentVal + '%';
            else if (isCurrency) obj.innerHTML = '₦' + (currentVal / 1000000).toFixed(0) + 'M+';
            else obj.innerHTML = currentVal;
            if (progress < 1) window.requestAnimationFrame(step);
        };
        window.requestAnimationFrame(step);
    }
    if (document.getElementById('metric1')) {
        animateValue("metric1", 0, 340000000, 2000, true, false);
        animateValue("metric2", 0, 48, 1500, false, false);
        animateValue("metric3", 0, 112000000, 2000, true, false);
        animateValue("metric4", 0, 100, 1000, false, true);
    }

    // Floating Popup
    const popupNode = document.getElementById('popupNode');
    if (popupNode) {
        const institutions = ["LASUED", "UNILAG", "UI", "LASU", "OAU", "ABU", "UNIBEN", "UNN"];
        const popupTitle = document.getElementById('popupTitle');
        const popupBody = document.getElementById('popupBody');
        function triggerPopup() {
            const randomInst = institutions[Math.floor(Math.random() * institutions.length)];
            const randomNode = Math.floor(100 + Math.random() * 899);
            if (popupTitle) popupTitle.innerHTML = `Student Ticket Verified`;
            if (popupBody) popupBody.innerHTML = `University entry code generated for card node context -[${randomInst}-${randomNode}]. Payment protection tracking active.`;
            popupNode.classList.add('popup-visible');
            setTimeout(() => popupNode.classList.remove('popup-visible'), 4500);
        }
        setInterval(triggerPopup, Math.floor(8000 + Math.random() * 6000));
        setTimeout(triggerPopup, 3000);
    }

    // Winners Spotlight (Homepage)
    function renderWinnersSpotlight() {
        fetch('/api/selection/recent').then(r => r.json()).then(payload => {
            if (!payload || !payload.success) return;
            const sel = payload.selection;
            const grandEl = document.getElementById('spotlight-grand');
            const grandIdEl = document.getElementById('spotlight-grand-id');
            if (!sel) { if (grandEl) grandEl.textContent = 'Awaiting Saturday\'s Draw'; if (grandIdEl) grandIdEl.textContent = ''; return; }
            if (grandEl) grandEl.textContent = sel.grand && (sel.grand.nodeCode || sel.grand.email) || '—';
            if (grandIdEl && sel.grand) grandIdEl.textContent = sel.grand.email ? sel.grand.email : '';
        }).catch(() => {});
    }
    renderWinnersSpotlight();

    // ============================================================
    // PART 11: MODEL PAGE (Calculator + Accordion)
    // ============================================================
    const qtyInput = document.getElementById('ticket-qty-input');
    if (qtyInput) {
        const outflow = document.getElementById('calc-total-outflow');
        const refund = document.getElementById('calc-guaranteed-refund');
        const risk = document.getElementById('calc-actual-risk');
        function updateCalc() {
            let q = parseInt(qtyInput.value) || 1;
            if (q < 1) q = 1;
            const total = q * 5000;
            const cash = q * 2500;
            outflow.textContent = "₦" + total.toLocaleString();
            refund.textContent = "₦" + cash.toLocaleString();
            risk.textContent = "₦" + (total - cash).toLocaleString();
        }
        qtyInput.addEventListener('input', updateCalc);
        qtyInput.addEventListener('blur', () => { if (qtyInput.value < 1 || qtyInput.value === "") { qtyInput.value = 1; updateCalc(); } });
        updateCalc();
    }

    document.querySelectorAll('.accordion-trigger').forEach(trigger => {
        trigger.addEventListener('click', function() {
            const panel = this.parentElement;
            const isOpen = panel.classList.contains('is-open');
            document.querySelectorAll('.accordion-panel').forEach(p => p.classList.remove('is-open'));
            if (!isOpen) panel.classList.add('is-open');
        });
    });

    // ============================================================
    // PART 12: LEDGER FILTERS
    // ============================================================
    let currentStatusFilter = 'all';
    function filterHistoricalTable() {
        const search = document.getElementById('ledger-search-input')?.value.toLowerCase() || '';
        const rows = document.querySelectorAll('#historical-ledger-table tbody .ledger-row');
        rows.forEach(row => {
            const name = row.cells[2]?.textContent.toLowerCase() || '';
            const status = row.getAttribute('data-status');
            const matchSearch = name.includes(search);
            const matchFilter = currentStatusFilter === 'all' || status === currentStatusFilter;
            row.style.display = (matchSearch && matchFilter) ? '' : 'none';
        });
    }
    window.setTableFilter = function(filter) {
        currentStatusFilter = filter;
        document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        const target = document.querySelector(`.filter-btn[data-filter="${filter}"]`);
        if (target) target.classList.add('active');
        filterHistoricalTable();
    };
    const searchInput = document.getElementById('ledger-search-input');
    if (searchInput) searchInput.addEventListener('input', filterHistoricalTable);
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            window.setTableFilter(this.getAttribute('data-filter'));
        });
    });

    // ============================================================
    // PART 13: LEDGER WINNER FETCH (Secondary list)
    // ============================================================
    fetch('/api/selection/recent').then(r => r.json()).then(payload => {
        if (!payload || !payload.success) return;
        const sel = payload.selection;
        const winnerName = document.getElementById('dynamic-winner-name');
        const secondaryList = document.getElementById('secondary-winners-list');
        if (winnerName && sel && sel.grand) {
            winnerName.textContent = sel.grand.nodeCode || sel.grand.email || sel.grand.firstName || '—';
            document.getElementById('winner-announcement-block').style.display = 'block';
        }
        if (secondaryList && sel && sel.secondary && sel.secondary.length > 0) {
            secondaryList.innerHTML = '';
            sel.secondary.slice(0,5).forEach(w => {
                const li = document.createElement('li');
                li.textContent = w.nodeCode || w.email || w.firstName || '—';
                secondaryList.appendChild(li);
            });
            document.getElementById('secondary-winners-block').style.display = 'block';
        }
    }).catch(() => {});

    // ============================================================
    // PART 14: INITIALIZE TIMERS & LEDGER UPDATES
    // ============================================================
    runEcosystemTimer();
    updateLedgerTableRecords();
    setInterval(() => { runEcosystemTimer(); updateLedgerTableRecords(); }, 1000);

}); // END DOMContentLoaded

// ============================================================
// PART 15: FAQ ACCORDION (Dedicated Page + Homepage)
// ============================================================
document.querySelectorAll('.accordion-trigger').forEach(trigger => {
    trigger.addEventListener('click', function() {
        const panel = this.parentElement;
        const isOpen = panel.classList.contains('is-open');

        // Close all other panels (optional — uncomment for exclusive open)
        // document.querySelectorAll('.accordion-panel').forEach(p => p.classList.remove('is-open'));

        if (isOpen) {
            panel.classList.remove('is-open');
        } else {
            panel.classList.add('is-open');
        }
    });
});

// ============================================================
// PART 15: FAQ ACCORDION (Homepage, Model, etc.)
// ============================================================
document.querySelectorAll('.accordion-trigger').forEach(trigger => {
    trigger.addEventListener('click', function() {
        const panel = this.parentElement; // .accordion-panel
        const isOpen = panel.classList.contains('is-open');

        // Toggle the current panel
        if (isOpen) {
            panel.classList.remove('is-open');
        } else {
            panel.classList.add('is-open');
        }
    });
});

// ============================================================
// PART 16: CINEMATIC SCROLL REVEAL
// ============================================================
const scrollRevealElements = document.querySelectorAll('.scroll-reveal');

const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
        }
    });
}, {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
});

scrollRevealElements.forEach(el => {
    revealObserver.observe(el);
});

// ============================================================
// PART 17: DYNAMIC HERO GLITCH EFFECT (Optional)
// ============================================================
const heroHeadings = document.querySelectorAll('.hero h1, .model-hero h1, .benefactors-hero h1, .ledger-hero h1');

heroHeadings.forEach(heading => {
    heading.addEventListener('mouseenter', function() {
        this.classList.add('glitch-active');
        setTimeout(() => {
            this.classList.remove('glitch-active');
        }, 300);
    });
});

// ============================================================
// PART 18: PARALLAX BACKGROUND ON MOUSE MOVE (Hero only)
// ============================================================
const heroSections = document.querySelectorAll('.hero, .model-hero, .benefactors-hero, .ledger-hero');

heroSections.forEach(section => {
    section.addEventListener('mousemove', function(e) {
        const rect = this.getBoundingClientRect();
        const x = (e.clientX - rect.left) / rect.width - 0.5;
        const y = (e.clientY - rect.top) / rect.height - 0.5;
        
        const title = this.querySelector('h1');
        const subtext = this.querySelector('.hero-subtext');
        
        if (title) {
            title.style.transform = `translate(${x * 15}px, ${y * 10}px)`;
        }
        if (subtext) {
            subtext.style.transform = `translate(${x * 8}px, ${y * 5}px)`;
        }
    });
    
    section.addEventListener('mouseleave', function() {
        const title = this.querySelector('h1');
        const subtext = this.querySelector('.hero-subtext');
        
        if (title) {
            title.style.transform = 'translate(0, 0)';
            title.style.transition = 'transform 0.5s ease';
        }
        if (subtext) {
            subtext.style.transform = 'translate(0, 0)';
            subtext.style.transition = 'transform 0.5s ease';
        }
    });
});